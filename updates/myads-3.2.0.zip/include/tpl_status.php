<?PHP

#####################################################################
##                                                                 ##
##                        MYads  v3.2.x                            ##
##                  https://github.com/mrghozzi                    ##
##                                                                 ##
##                                                                 ##
##                       copyright (c) 2025                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################
if($s_st=="buyfgeufb"){
    
 //  Get Browser
include "./templates/_panel/tpl/tpl_site_stt.php";
include "./templates/_panel/tpl/tpl_topic_stt.php";
include "./templates/_panel/tpl/tpl_news_stt.php";
include "./templates/_panel/tpl/tpl_image_stt.php";
include "./templates/_panel/tpl/tpl_store_stt.php";
include "./templates/_panel/tpl/tpl_post_stt.php";

include "./templates/_panel/tpl/tpl_site_vst.php";

}else{ echo"404"; }
 ?>