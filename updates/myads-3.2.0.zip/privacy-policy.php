<?PHP

#####################################################################
##                                                                 ##
##                        MYads  v3.2.x                            ##
##                  https://github.com/mrghozzi                    ##
##                                                                 ##
##                                                                 ##
##                       copyright (c) 2025                        ##
##                                                                 ##
##                    This script is freeware                      ##
##                                                                 ##
#####################################################################


require "dbconfig.php";
require "include/function.php";
$title_page = "PRIVACY POLICY";

 template_mine('header');
 template_mine('privacy-policy');
 template_mine('footer');


?>

