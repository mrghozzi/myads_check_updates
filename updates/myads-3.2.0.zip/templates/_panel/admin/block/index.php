﻿<?php
 @header("Location: https://www.adstn.gq/404") ; 
  ?>
