<?php if(isset($s_st) AND ($s_st=="buyfgeufb")){ ?>
<div class="widget-box">
          <!-- WIDGET BOX TITLE -->
          <p class="widget-box-title"><?php echo $abwidgets['name']; ?></p>
          <!-- /WIDGET BOX TITLE -->

          <!-- WIDGET BOX CONTENT -->
          <div class="widget-box-content">
           <?php echo $abwidgets['o_valuer']; ?>
          </div>
          <!-- /WIDGET BOX CONTENT -->
        </div>
<?php } ?>
