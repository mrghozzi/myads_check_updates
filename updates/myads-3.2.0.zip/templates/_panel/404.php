<?php if(isset($s_st) AND ($s_st=="buyfgeufb")){  ?>
  <style> body{  background-image: url(<?php url_site();  ?>/templates/_panel/img/background.webp); } </style>
  <div class="grid grid-12" >
  <div class="grid-column" >
    <div class="widget-box" >
<!-- ERROR SECTION -->
  <div class="error-section">
    <!-- ERROR SECTION TITLE -->
    <!-- /ERROR SECTION TITLE -->

    <!-- ERROR SECTION INFO -->
    <div class="error-section-info">
      <!-- ERROR SECTION SUBTITLE -->
      <p class="error-section-subtitle">404</p>
      <!-- /ERROR SECTION SUBTITLE -->

      <!-- ERROR SECTION TEXT -->
      <p class="error-section-text">Seems that you made a wrong turn and encountered a web black hole that absorbed the page you were looking for! But don't panic because you can go back!</p>
      <!-- /ERROR SECTION TEXT -->

    </div>
    <!-- /ERROR SECTION INFO -->
  </div>
  <!-- /ERROR SECTION -->
  </div>
   </div>
</div>
<?php }else{ echo"404"; }  ?>