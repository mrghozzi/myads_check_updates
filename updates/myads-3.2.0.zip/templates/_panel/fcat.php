<?php if (isset($s_st) AND ($s_st == "buyfgeufb")) { dinstall_d(); ?>
<!-- SECTION BANNER -->
<div class="section-banner" style="background: url(<?php url_site(); ?>/templates/_panel/img/banner/Newsfeed.png) no-repeat 50%;">
    <!-- SECTION BANNER ICON -->
    <img class="section-banner-icon" src="<?php url_site(); ?>/templates/_panel/img/banner/discussion-icon.png">
    <!-- /SECTION BANNER ICON -->

    <!-- SECTION BANNER TITLE -->
    <p class="section-banner-title"><?php lang('forum'); ?></p>
    <!-- /SECTION BANNER TITLE -->

    <!-- SECTION BANNER TEXT -->
    <p class="section-banner-text"></p>
    <!-- /SECTION BANNER TEXT -->
</div>
<!-- /SECTION BANNER -->

<?php ads_site(4); ?>

<div class="section-filters-bar v6">
    <!-- SECTION FILTERS BAR ACTIONS -->
    <div class="section-filters-bar-actions">
        <?php if (isset($elnk_site) AND ($elnk_site == 1)) { ?>
        <a href="https://github.com/mrghozzi/myads/wiki/post" class="button primary" target="_blank">
            <b><i class="fa fa-question-circle" aria-hidden="true"></i></b>
        </a>
        <?php } ?>
    </div>
    <?php if (isset($_COOKIE['user'])) { ?>
    <div class="section-filters-bar-actions">
        <!-- BUTTON -->
        <a href="<?php url_site(); ?>/post" class="button secondary" style="color: #fff;">
            <i class="fa fa-plus nav_icon"></i>&nbsp;<?php lang('add'); ?>
        </a>
        <!-- /BUTTON -->
    </div>
    <?php } ?>
    <!-- /SECTION FILTERS BAR ACTIONS -->
</div>

<div class="table table-forum">
    <!-- TABLE HEADER -->
    <div class="table-header">
        <div class="table-header-column">
            <p class="table-header-title"><?php lang('cat_s'); ?></p>
        </div>
        <div class="table-header-column centered padded-medium">
            <p class="table-header-title"><?php lang('topics'); ?></p>
        </div>
        <div class="table-header-column padded-big-left">
            <p class="table-header-title"><?php lang('latest_post'); ?></p>
        </div>
    </div>
    <!-- /TABLE HEADER -->

    <!-- TABLE BODY -->
    <div class="table-body">
        <?php
        $statement = "`f_cat` WHERE id ORDER BY `ordercat` ASC";
        $results = $db_con->prepare("SELECT * FROM {$statement}");
        $results->execute();

        while ($wt = $results->fetch(PDO::FETCH_ASSOC)) {
            $catdids = $wt['id'];
            $catcount = $db_con->prepare("SELECT COUNT(id) as nbr FROM forum WHERE statu=1 AND cat={$catdids}");
            $catcount->execute();
            $abcat = $catcount->fetch(PDO::FETCH_ASSOC);

            $catusz = $db_con->prepare("SELECT * FROM `forum` WHERE statu=1 AND cat={$catdids} ORDER BY `id` DESC");
            $catusz->execute();
            $sucat = $catusz->fetch(PDO::FETCH_ASSOC);

            $catdid = $sucat['id'];
            $time_stt = isset($catdid) ? convertTime($db_con->prepare("SELECT date FROM status WHERE tp_id='{$catdid}' AND s_type=2")->fetch(PDO::FETCH_ASSOC)['date']) : "";

            $cat_txt = nl2br(strip_tags($wt['txt'], '<br>'));
        ?>
        <!-- TABLE ROW -->
        <div class="table-row big">
            <div class="table-column">
                <div class="forum-category">
                    <a href="<?php echo "{$url_site}/f{$wt['id']}"; ?>">
                        <i class="fa <?php echo $wt['icons']; ?>" aria-hidden="true"></i>
                    </a>
                    <div class="forum-category-info">
                        <p class="forum-category-title">
                            <a href="<?php echo "{$url_site}/f{$wt['id']}"; ?>"><?php echo $wt['name']; ?></a>
                        </p>
                        <p class="forum-category-text"><?php echo $cat_txt; ?></p>
                    </div>
                </div>
            </div>
            <div class="table-column centered padded-medium">
                <p class="table-title"><?php echo $abcat['nbr']; ?></p>
            </div>
            <div class="table-column padded-big-left">
                <a class="table-link" href="<?php echo "{$url_site}/t{$sucat['id']}"; ?>"><?php echo $sucat['name']; ?></a>
                <a class="table-link" href="<?php echo "{$url_site}/t{$sucat['id']}"; ?>">
                    <i class="fa fa-clock-o" aria-hidden="true"></i> منذ <?php echo $time_stt; ?>
                </a>
            </div>
        </div>
        <!-- /TABLE ROW -->
        <?php } ?>
    </div>
    <!-- /TABLE BODY -->
</div>
<?php } else { echo "404"; } ?>